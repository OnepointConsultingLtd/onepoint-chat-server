# Meet Our Team | Onepoint - Do data better | Innovate with AI & more | Architect for Outcomes

Source: https://www.onepointltd.com/discover-onepoint/meet-our-team/

_Onepoint is a London headquartered, architecture-led boutique technology consultancy that delivers AI-powered, data-driven enterprise solutions for global clients._

## Content

- Architect for outcomes
- Do data better
- Innovate with AI & more
-
-
-
- Search for:Search

Architect for outcomes[1]

Do data better[2]

Innovate with AI & more[3]

Home[4]

Discover Onepoint[5]

## Shashin Shah

###

### Founder and Chief Executive Officer

-

Read more

Read more[6]

## Alexander (Sasha) Polev

###

### Chief Technology Officer

-

Read more

Read more[7]

## Maithili Shetty

###

### Chief Operations Officer

-

Read more

Read more[8]

## Sangeetha Viswanathan

###

### Head of Delivery and Operations

-

Read more

Read more[9]

## Els Braeken

###

### Head of Risk & Governance

-

Read more

Read more[10]

## Chris Wray

###

### Senior Advisor

-

Read more

Read more[11]

## Christy Kulasingam

###

### Strategic Advisor and Mentor

-

Read more

Read more[12]

MEET OUR TEAM

## Featured team members

Shashin Shah

Founder and Chief Executive Officer

London

[Read more](/meet-our-team/shashin-shah/)

Alexander(Sasha) Polev

Director of Technology (Strategy)

London

[Read more](/meet-our-team/alexander-sasha-polev-3/)

Allan Schweitz

Director of Technology (Services)

London

[Read more](/meet-our-team/allan-schweitz-3/)

Sangeetha Viswanathan

Director, Project Delivery and Operations

London

[Read more](/meet-our-team//sangeetha-viswanathan/)

Samir Dadia

Managing Director (India)

Pune

Maithili Shetty

Director of Operations (India)

Pune

[Read more](/meet-our-team/maithili-shetty/)

Suresh Sharma

Chief Client Officer

London

Rajesh Patel

Head of Managed Services

London

Miguel Vale

Principal Solution Architect

London

Garima Dosi

Principal Solution Architect

Pune

Chris Wray

Senior Advisor

London

[Read more](/meet-our-team/chris-wray-2/)

Christy Kulasingam

Strategic Advisor and Mentor

London

[Read more](/meet-our-team/christy-kulasingam-2/)

## Onepoint UK

## Onepoint India

- What we doArchitect for outcomesDo data betterInnovate with AI & moreSpringboard™ WorkshopOnepoint Labs

Architect for outcomes

[Architect for outcomes](/architect-for-outcomes/)

Do data better

[Do data better](/do-data-better)

Innovate with AI & more

[Innovate with AI & more](/innovate-with-ai-more/)

Springboard™ Workshop

[Springboard™ Workshop](/onepoint-springboard/)

Onepoint Labs

[Onepoint Labs](/onepoint-labs/)

- ResourcesOnepoint Data Wellness™ SuiteOnepoint Res-AI™Onepoint TechTalkOnepoint Oneness

Onepoint Data Wellness™ Suite

[Onepoint Data Wellness™ Suite](/data-wellness/)

Onepoint Res-AI™

[Onepoint Res-AI™](/onepoint-res-ai/)

Onepoint TechTalk

[Onepoint TechTalk](/techtalk)

Onepoint Oneness

[Onepoint Oneness](/oneness/)

- About usDiscover OnepointClient storiesCareerContact us

Discover Onepoint

[Discover Onepoint](/discover-onepoint/)

Client stories

[Client stories](/client-stories/)

Career

[Career](/career-opportunities/)

Contact us

[Contact us](/contact-us/)

© Copyright 2025 Onepoint Consulting Ltd| Terms| Privacy notice

[| Terms](/policies/)

[| Privacy notice](/policies/privacy-policy/)

## Sources

[1] Architect for outcomes: https://www.onepointltd.com/architect-for-outcomes/
[2] Do data better: https://www.onepointltd.com/do-data-better
[3] Innovate with AI & more: https://www.onepointltd.com/innovate-with-ai-more
[4] Home: https://www.onepointltd.com
[5] Discover Onepoint: https://www.onepointltd.com/discover-onepoint/
[6] Read more: https://www.onepointltd.com/meet-our-team/shashin-shah/
[7] Read more: https://www.onepointltd.com/meet-our-team/alexander-sasha-polev-3/
[8] Read more: https://www.onepointltd.com/meet-our-team/maithili-shetty/
[9] Read more: https://www.onepointltd.com/meet-our-team/sangeetha-viswanathan/
[10] Read more: https://www.onepointltd.com/meet-our-team/els-braeken
[11] Read more: https://www.onepointltd.com/meet-our-team/chris-wray-2/
[12] Read more: https://www.onepointltd.com/meet-our-team/christy-kulasingam-2/

## Metadata

- URL: https://www.onepointltd.com/discover-onepoint/meet-our-team/
- Last Scraped: 2025-08-09 14:09:58
- Content Type: Web Page
